Change Log: `Aksoyhlc İş-Proje Takip Scripti`
===================================
## Version 1.0.0

**Tarih:** 06.04.2019

Proje Ekleme
Proje Düzenleme
Proje Silme
Projeye Dosya Ekleme (Resim ve Zip-Rar)
Proje Aciliyet Ve Durum Belirleme

Sipariş Ekleme
Sipariş Düzenleme
Sipariş Silme
Siparişe Dosya Ekleme (Resim ve Zip-Rar)
Sipariş Aciliyet Ve Durum Belirleme